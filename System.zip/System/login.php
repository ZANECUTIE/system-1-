<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alpha Kappa Rho - Zamboanga City Council</title>
    <link rel="stylesheet" href="style_login.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>ALPHA KAPPA RHO</h1>
            <p>INTERNATIONAL HUMANITARIAN SERVICE FRATERNITY AND SORORITY</p>
            <h2>Zamboanga City Council</h2>
        </div>

        <div class="form-container">
            <div class="logo-placeholder">
                <img src="images/logo.jpg" alt="Logo Placeholder">
            </div>

            <div class="login-box">
                <div class="input-box">Email</div>
                <div class="input-box">Password</div>
            </div>
        </div>
    </div>
</body>
</html>