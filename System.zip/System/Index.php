<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>

    <div class="sidebar">
        <div class="left_img_cont">
            <img src="images/right.png" alt="left-side image" id="left-image">
        </div>
        <div class="navs">
            <li>
                <a href="profile.php" class="profile-link">MY PROFILE<i class='bx bx-home-alt-2'></i></a>
            </li>
            <li> 
                <a href="chapters.php" class ="chapter-rules">CHAPTER RULES & REGULATIONS BY LAWS<i class='bx bx-file'></i></a>
            </li>
            <li>5 PILLARS <i class='bx bx-flag'></i></li>
            <li>13 DOCTRINES <i class='bx bx-book-open'></i></li>
            <li>FOUNDING AND FATHERS <i class='bx bx-group'></i></li>
            <li>ACTIVITIES AND EVENTS <i class='bx bx-calendar'></i></li>
            <li>TEAMS <i class='bx bx-group'></i></li>
            <li>SERVICES <i class='bx bx-cog'></i></li>
        </div>
    </div>

    <div class="content">
        <div class="header">
            <h1>ALPHA KAPPA RHO</h1>
            <p>INTERNATIONAL HUMANITARIAN SERVICE FRATERNITY AND SORORITY</p>
            <h3>Zamboanga City Council</h3>
        </div>
        <img src="images/front-removebg-preview.png" alt="right-side image" id="right-image">
    </div>

</body>

</html>


